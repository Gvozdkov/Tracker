import UIKit

struct TrackerCategory: Hashable {
    let name: String
    let trackers: [Tracker]
}
