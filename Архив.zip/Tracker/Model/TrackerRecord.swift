import Foundation

struct TrackerRecord: Hashable {
    let trackerId: UUID
    let date: Date
}
